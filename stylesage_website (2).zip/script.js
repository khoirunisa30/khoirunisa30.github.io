// Simple site script: slider, products, cart
const products = [
  {id:1,title:'Casual Tee - Lavender',desc:'Soft cotton tee, relaxed fit.',price:129000, img:'assets/img1.svg'},
  {id:2,title:'Silk Scarf - Copper Trim',desc:'Elegant scarf with copper accents.',price:189000, img:'assets/img2.svg'},
  {id:3,title:'Oversized Hoodie - Plum',desc:'Cozy hoodie for daily wear.',price:249000, img:'assets/img3.svg'},
  {id:4,title:'Tailored Blouse - Mauve',desc:'Lightweight blouse for work.',price:199000, img:'assets/img1.svg'},
  {id:5,title:'Denim Skirt - Classic',desc:'Everyday denim with modern cut.',price:179000, img:'assets/img2.svg'}
];

const productGrid = document.getElementById('productGrid');
const template = document.getElementById('productTemplate');

function renderProducts(){
  products.forEach(p=>{
    const node = template.content.cloneNode(true);
    node.querySelector('img').src = p.img;
    node.querySelector('img').alt = p.title;
    node.querySelector('.p-title').textContent = p.title;
    node.querySelector('.p-desc').textContent = p.desc;
    node.querySelector('.p-price').textContent = p.price.toLocaleString('id-ID');
    const btn = node.querySelector('.add-to-cart');
    btn.addEventListener('click', ()=> addToCart(p));
    productGrid.appendChild(node);
  });
}

/* Cart (local only) */
let cart = [];
const cartBtn = document.getElementById('cartBtn');
const cartModal = document.getElementById('cartModal');
const cartCount = document.getElementById('cartCount');
const cartItemsEl = document.getElementById('cartItems');
const cartTotalEl = document.getElementById('cartTotal');

function updateCartUI(){
  cartCount.textContent = cart.reduce((s,i)=>s+i.qty,0);
  cartItemsEl.innerHTML = '';
  let total = 0;
  cart.forEach(it=>{
    total += it.qty * it.price;
    const el = document.createElement('div');
    el.className = 'item';
    el.innerHTML = `
      <img src="${it.img}" alt="${it.title}" />
      <div style="flex:1">
        <div style="font-weight:600">${it.title}</div>
        <div style="font-size:13px;color:#666">Rp ${it.price.toLocaleString('id-ID')}</div>
        <div style="margin-top:6px">
          <button data-id="${it.id}" class="qty-decrease">-</button>
          <span style="padding:0 8px">${it.qty}</span>
          <button data-id="${it.id}" class="qty-increase">+</button>
        </div>
      </div>
    `;
    cartItemsEl.appendChild(el);
  });
  cartTotalEl.textContent = total.toLocaleString('id-ID');
  // qty buttons
  cartItemsEl.querySelectorAll('.qty-increase').forEach(b=>{
    b.addEventListener('click', (e)=>{
      const id = +b.dataset.id;
      changeQty(id,1);
    });
  });
  cartItemsEl.querySelectorAll('.qty-decrease').forEach(b=>{
    b.addEventListener('click', (e)=>{
      const id = +b.dataset.id;
      changeQty(id,-1);
    });
  });
}

function addToCart(p){
  const found = cart.find(x=>x.id===p.id);
  if(found) found.qty++;
  else cart.push({...p,qty:1});
  animateAddToCart();
  updateCartUI();
}

function changeQty(id,delta){
  const idx = cart.findIndex(x=>x.id===id);
  if(idx===-1) return;
  cart[idx].qty += delta;
  if(cart[idx].qty<=0) cart.splice(idx,1);
  updateCartUI();
}

function animateAddToCart(){
  // tiny pulse on cart button
  cartBtn.animate([{transform:'scale(1)'},{transform:'scale(1.08)'},{transform:'scale(1)'}],{duration:350});
}

/* Cart modal controls */
cartBtn.addEventListener('click', ()=> {
  cartModal.classList.toggle('hidden');
});
document.getElementById('closeCart').addEventListener('click', ()=> cartModal.classList.add('hidden'));
document.getElementById('clearCart').addEventListener('click', ()=> { cart = []; updateCartUI(); });

document.getElementById('checkout').addEventListener('click', ()=> {
  if(cart.length===0){ alert('Keranjang kosong'); return; }
  // simple checkout mock
  alert('Terima kasih! Pesananmu telah diterima (demo).');
  cart = [];
  updateCartUI();
});

/* Slider */
const slidesWrap = document.querySelector('.slides');
const imgs = slidesWrap.querySelectorAll('img');
let idx = 0;
function showSlide(i){
  idx = (i + imgs.length) % imgs.length;
  slidesWrap.style.transform = `translateX(${-idx * 100}%)`;
}
document.getElementById('next').addEventListener('click', ()=> showSlide(idx+1));
document.getElementById('prev').addEventListener('click', ()=> showSlide(idx-1));
setInterval(()=> showSlide(idx+1), 4500);

/* Init */
renderProducts();
updateCartUI();
