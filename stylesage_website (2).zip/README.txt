Stylesage — Simple modern website
Files:
- index.html
- styles.css
- script.js
- assets/img1.svg, img2.svg, img3.svg

How to use:
1. Download the zip.
2. Unzip and upload the folder to GitHub (create a repo and push), or directly drag to GitHub Pages.
3. index.html is the homepage.

This is a demo front-end (no backend). Checkout is a mock alert for demonstration.
Owner: Deswita — Stylesage
